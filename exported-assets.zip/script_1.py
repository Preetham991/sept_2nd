# Fix the entropy import and continue with the script
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    log_loss, brier_score_loss, roc_auc_score, roc_curve, 
    precision_recall_curve, auc, accuracy_score, classification_report
)
from sklearn.calibration import calibration_curve
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from scipy import stats
import os
import warnings
warnings.filterwarnings('ignore')

# Set random seed for reproducibility
np.random.seed(42)

def entropy_score(probabilities):
    """Calculate entropy manually"""
    # Add small epsilon to avoid log(0)
    eps = 1e-8
    probabilities = np.clip(probabilities, eps, 1.0)
    return -np.sum(probabilities * np.log(probabilities), axis=1)

def generate_dataset():
    """
    Generate synthetic email classification dataset with 5 classes:
    0: Spam, 1: Promotions, 2: Social, 3: Updates, 4: Forums
    Creates 500 samples with class imbalance and calibration mismatches
    """
    n_samples = 500
    n_classes = 5
    class_names = ['Spam', 'Promotions', 'Social', 'Updates', 'Forums']
    
    # Create imbalanced class distribution
    class_probs = [0.35, 0.25, 0.20, 0.15, 0.05]  # Imbalanced
    true_labels = np.random.choice(n_classes, size=n_samples, p=class_probs)
    
    # Generate logits with varying confidence patterns per class
    logits = np.zeros((n_samples, n_classes))
    
    for i, label in enumerate(true_labels):
        # Base logits for correct class
        correct_logit = np.random.normal(2.5, 1.0)  # Higher for correct class
        logits[i, label] = correct_logit
        
        # Add noise to other classes
        for j in range(n_classes):
            if j != label:
                # Some classes more confusable than others
                if (label == 0 and j == 1) or (label == 2 and j == 3):  # Confusable pairs
                    logits[i, j] = np.random.normal(1.8, 0.8)
                else:
                    logits[i, j] = np.random.normal(0.5, 1.2)
    
    # Convert to probabilities
    probabilities = np.exp(logits) / np.sum(np.exp(logits), axis=1, keepdims=True)
    predictions = np.argmax(probabilities, axis=1)
    
    # Add some miscalibration by artificially inflating confidence for some samples
    miscalib_mask = np.random.choice([True, False], size=n_samples, p=[0.3, 0.7])
    probabilities[miscalib_mask] = probabilities[miscalib_mask] ** 0.7  # Make overconfident
    probabilities = probabilities / np.sum(probabilities, axis=1, keepdims=True)  # Renormalize
    
    dataset = {
        'probabilities': probabilities,
        'predictions': predictions,
        'true_labels': true_labels,
        'class_names': class_names,
        'n_samples': n_samples,
        'n_classes': n_classes
    }
    
    return dataset

def confidence_scores(probabilities):
    """
    Compute various confidence scoring methods
    
    Returns:
    - msp: Maximum Softmax Probability
    - entropy_conf: 1 - normalized entropy (higher = more confident)
    - margin: Difference between top two probabilities
    """
    # Maximum Softmax Probability
    msp = np.max(probabilities, axis=1)
    
    # Entropy-based confidence (normalized)
    entropies = entropy_score(probabilities)
    max_entropy = np.log(probabilities.shape[1])
    entropy_conf = 1 - (entropies / max_entropy)
    
    # Margin (difference between top two predictions)
    sorted_probs = np.sort(probabilities, axis=1)
    margin = sorted_probs[:, -1] - sorted_probs[:, -2]
    
    return {
        'msp': msp,
        'entropy': entropy_conf,
        'margin': margin
    }

def calibration_methods(probabilities, true_labels, confidence_scores):
    """
    Apply different calibration methods
    
    Returns calibrated probabilities and temperatures
    """
    n_samples = len(true_labels)
    split_idx = n_samples // 2
    
    # Split for calibration
    cal_probs = probabilities[:split_idx]
    cal_labels = true_labels[:split_idx]
    val_probs = probabilities[split_idx:]
    val_labels = true_labels[split_idx:]
    
    results = {}
    
    # Temperature Scaling
    def find_temperature(logits, labels):
        """Find optimal temperature using validation set"""
        def temperature_scale(logits, temp):
            return logits / temp
        
        # Convert probabilities back to logits (approximate)
        logits_approx = np.log(logits + 1e-8)
        
        best_temp = 1.0
        best_nll = float('inf')
        
        for temp in np.linspace(0.5, 3.0, 50):
            scaled_logits = temperature_scale(logits_approx, temp)
            scaled_probs = np.exp(scaled_logits) / np.sum(np.exp(scaled_logits), axis=1, keepdims=True)
            
            try:
                nll = log_loss(labels, scaled_probs)
                if nll < best_nll:
                    best_nll = nll
                    best_temp = temp
            except:
                continue
                
        return best_temp
    
    optimal_temp = find_temperature(cal_probs, cal_labels)
    logits_approx = np.log(probabilities + 1e-8)
    temp_scaled_logits = logits_approx / optimal_temp
    temp_calibrated = np.exp(temp_scaled_logits) / np.sum(np.exp(temp_scaled_logits), axis=1, keepdims=True)
    
    results['temperature'] = {
        'probabilities': temp_calibrated,
        'temperature': optimal_temp
    }
    
    # Platt Scaling (on MSP scores)
    platt_model = LogisticRegression()
    correct_mask = (np.argmax(cal_probs, axis=1) == cal_labels).astype(int)
    cal_msp = np.max(cal_probs, axis=1)
    
    try:
        platt_model.fit(cal_msp.reshape(-1, 1), correct_mask)
        platt_scores = platt_model.predict_proba(confidence_scores['msp'].reshape(-1, 1))[:, 1]
        results['platt'] = {
            'scores': platt_scores,
            'model': platt_model
        }
    except:
        results['platt'] = {
            'scores': confidence_scores['msp'],
            'model': None
        }
    
    # Isotonic Regression
    iso_model = IsotonicRegression(out_of_bounds='clip')
    try:
        iso_model.fit(cal_msp, correct_mask.astype(float))
        iso_scores = iso_model.predict(confidence_scores['msp'])
        results['isotonic'] = {
            'scores': iso_scores,
            'model': None
        }
    except:
        results['isotonic'] = {
            'scores': confidence_scores['msp'],
            'model': None
        }
    
    return results

print("Fixed entropy import and updated calibration methods.")
print("Core functions ready for email confidence evaluation.")