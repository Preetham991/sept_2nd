# Continue with remaining visualization functions
def generate_remaining_visualizations(dataset, confidence_scores, calibration_results, metrics):
    """
    Generate remaining visualization plots (5-14)
    """
    probabilities = dataset['probabilities']
    predictions = dataset['predictions'] 
    true_labels = dataset['true_labels']
    class_names = dataset['class_names']
    correct = (predictions == true_labels)
    
    # 5. Confidence-Correctness Heatmap
    plt.figure(figsize=(10, 8))
    
    # Create bins for confidence and compute accuracy in each bin
    conf_bins = np.linspace(0, 1, 11)
    heatmap_data = np.zeros((len(class_names), len(conf_bins)-1))
    
    for i, class_name in enumerate(class_names):
        class_mask = (true_labels == i)
        if np.sum(class_mask) > 0:
            class_conf = confidence_scores['msp'][class_mask]
            class_correct = correct[class_mask].astype(float)
            
            for j in range(len(conf_bins)-1):
                bin_mask = (class_conf >= conf_bins[j]) & (class_conf < conf_bins[j+1])
                if np.sum(bin_mask) > 0:
                    heatmap_data[i, j] = np.mean(class_correct[bin_mask])
    
    sns.heatmap(heatmap_data, 
                xticklabels=[f'{conf_bins[i]:.1f}-{conf_bins[i+1]:.1f}' for i in range(len(conf_bins)-1)],
                yticklabels=class_names,
                annot=True, fmt='.2f', cmap='RdYlBu_r')
    plt.xlabel('Confidence Bins')
    plt.ylabel('Classes')
    plt.title('Confidence vs Correctness Heatmap')
    plt.tight_layout()
    plt.savefig('figures/heatmap_confidence_correctness.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 6. Confidence Histogram
    plt.figure(figsize=(10, 6))
    
    # Separate histograms for correct and incorrect predictions
    correct_conf = confidence_scores['msp'][correct]
    incorrect_conf = confidence_scores['msp'][~correct]
    
    plt.hist(correct_conf, bins=20, alpha=0.7, label='Correct', color='green', density=True)
    plt.hist(incorrect_conf, bins=20, alpha=0.7, label='Incorrect', color='red', density=True)
    plt.xlabel('Confidence (MSP)')
    plt.ylabel('Density')
    plt.title('Confidence Distribution by Correctness')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/confidence_histogram.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 7. Violin Plot per Class
    plt.figure(figsize=(12, 6))
    
    conf_by_class = []
    labels_for_violin = []
    
    for i, class_name in enumerate(class_names):
        class_mask = (true_labels == i)
        if np.sum(class_mask) > 0:
            conf_by_class.append(confidence_scores['msp'][class_mask])
            labels_for_violin.append(class_name)
    
    parts = plt.violinplot(conf_by_class, positions=range(len(conf_by_class)))
    plt.xticks(range(len(labels_for_violin)), labels_for_violin, rotation=45)
    plt.ylabel('Confidence (MSP)')
    plt.title('Confidence Distribution by Class')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/violin_per_class.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 8. Confidence-Error Curve
    plt.figure(figsize=(8, 6))
    
    # Sort by confidence (descending)
    sorted_indices = np.argsort(-confidence_scores['msp'])
    sorted_correct = correct[sorted_indices]
    
    # Compute cumulative error rate
    cumulative_errors = np.cumsum(~sorted_correct) / np.arange(1, len(sorted_correct) + 1)
    coverage = np.arange(1, len(sorted_correct) + 1) / len(sorted_correct)
    
    plt.plot(coverage, cumulative_errors, 'b-', linewidth=2)
    plt.xlabel('Coverage (Fraction of Data)')
    plt.ylabel('Error Rate')
    plt.title('Confidence-Error Curve')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/confidence_error_curve.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 9. Temperature Sweep
    plt.figure(figsize=(10, 6))
    
    temperatures = np.linspace(0.5, 3.0, 20)
    ece_scores = []
    nll_scores = []
    
    logits_approx = np.log(probabilities + 1e-8)
    
    for temp in temperatures:
        temp_logits = logits_approx / temp
        temp_probs = np.exp(temp_logits) / np.sum(np.exp(temp_logits), axis=1, keepdims=True)
        temp_conf = np.max(temp_probs, axis=1)
        temp_preds = np.argmax(temp_probs, axis=1)
        temp_correct = (temp_preds == true_labels).astype(float)
        
        # Compute ECE
        def compute_ece_simple(confidences, accuracies, n_bins=10):
            bin_boundaries = np.linspace(0, 1, n_bins + 1)
            ece = 0
            for i in range(n_bins):
                in_bin = (confidences >= bin_boundaries[i]) & (confidences < bin_boundaries[i+1])
                if np.sum(in_bin) > 0:
                    bin_acc = np.mean(accuracies[in_bin])
                    bin_conf = np.mean(confidences[in_bin])
                    bin_prop = np.mean(in_bin)
                    ece += np.abs(bin_acc - bin_conf) * bin_prop
            return ece
        
        ece_temp = compute_ece_simple(temp_conf, temp_correct)
        ece_scores.append(ece_temp)
        
        try:
            nll_temp = log_loss(true_labels, temp_probs)
            nll_scores.append(nll_temp)
        except:
            nll_scores.append(np.nan)
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    ax1.plot(temperatures, ece_scores, 'b-', marker='o')
    ax1.set_xlabel('Temperature')
    ax1.set_ylabel('ECE')
    ax1.set_title('ECE vs Temperature')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(temperatures, nll_scores, 'r-', marker='s')
    ax2.set_xlabel('Temperature')
    ax2.set_ylabel('NLL')
    ax2.set_title('NLL vs Temperature')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('figures/temperature_sweep.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Generated plots 5-9 successfully!")

def generate_final_visualizations(dataset, confidence_scores, calibration_results, metrics):
    """
    Generate final visualization plots (10-14)
    """
    probabilities = dataset['probabilities']
    predictions = dataset['predictions'] 
    true_labels = dataset['true_labels']
    class_names = dataset['class_names']
    correct = (predictions == true_labels)
    
    # 10. Risk-Coverage Curve
    plt.figure(figsize=(8, 6))
    
    # Sort by confidence (descending for coverage)
    sorted_indices = np.argsort(-confidence_scores['msp'])
    sorted_correct = correct[sorted_indices]
    
    # Compute risk (error rate) at different coverage levels
    coverage_levels = np.linspace(0.1, 1.0, 50)
    risks = []
    
    for coverage in coverage_levels:
        n_samples_to_keep = int(coverage * len(sorted_correct))
        if n_samples_to_keep > 0:
            risk = 1 - np.mean(sorted_correct[:n_samples_to_keep])
            risks.append(risk)
        else:
            risks.append(1.0)
    
    plt.plot(coverage_levels, risks, 'b-', linewidth=2, label='Model')
    plt.xlabel('Coverage')
    plt.ylabel('Risk (Error Rate)')
    plt.title('Risk-Coverage Curve')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/risk_coverage_curve.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 11. ROC Curves Overlay (One-vs-Rest for each class)
    plt.figure(figsize=(8, 6))
    
    for i, class_name in enumerate(class_names):
        # Binary classification: class i vs rest
        y_binary = (true_labels == i).astype(int)
        y_scores = probabilities[:, i]
        
        if np.sum(y_binary) > 0 and np.sum(1 - y_binary) > 0:  # Check for both classes
            try:
                fpr, tpr, _ = roc_curve(y_binary, y_scores)
                auc_score = auc(fpr, tpr)
                plt.plot(fpr, tpr, label=f'{class_name} (AUC={auc_score:.3f})')
            except:
                continue
    
    plt.plot([0, 1], [0, 1], 'k--', alpha=0.5, label='Random')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curves (One-vs-Rest)')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/roc_overlay.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 12. Precision-Recall Curves Overlay
    plt.figure(figsize=(8, 6))
    
    for i, class_name in enumerate(class_names):
        # Binary classification: class i vs rest
        y_binary = (true_labels == i).astype(int)
        y_scores = probabilities[:, i]
        
        if np.sum(y_binary) > 0:  # Check for positive samples
            try:
                precision, recall, _ = precision_recall_curve(y_binary, y_scores)
                auc_score = auc(recall, precision)
                plt.plot(recall, precision, label=f'{class_name} (AUC={auc_score:.3f})')
            except:
                continue
    
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curves (One-vs-Rest)')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/pr_overlay.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 13. Cumulative Gain Chart
    plt.figure(figsize=(8, 6))
    
    # Sort by confidence (descending)
    sorted_indices = np.argsort(-confidence_scores['msp'])
    sorted_correct = correct[sorted_indices]
    
    # Compute cumulative gain
    cumulative_correct = np.cumsum(sorted_correct)
    total_correct = np.sum(correct)
    percentage_samples = np.arange(1, len(sorted_correct) + 1) / len(sorted_correct) * 100
    
    if total_correct > 0:
        cumulative_gain = cumulative_correct / total_correct * 100
    else:
        cumulative_gain = np.zeros_like(cumulative_correct)
    
    plt.plot(percentage_samples, cumulative_gain, 'b-', linewidth=2, label='Model')
    plt.plot([0, 100], [0, 100], 'k--', alpha=0.5, label='Random')
    plt.xlabel('Percentage of Samples')
    plt.ylabel('Cumulative Gain (%)')
    plt.title('Cumulative Gain Chart')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/cumulative_gain.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 14. Lift Chart
    plt.figure(figsize=(8, 6))
    
    # Compute lift (gain / random baseline)
    baseline_rate = total_correct / len(correct) if len(correct) > 0 else 0
    
    if baseline_rate > 0:
        lift = cumulative_gain / percentage_samples
    else:
        lift = np.ones_like(percentage_samples)
    
    plt.plot(percentage_samples, lift, 'g-', linewidth=2, label='Lift')
    plt.axhline(y=1, color='k', linestyle='--', alpha=0.5, label='Baseline')
    plt.xlabel('Percentage of Samples')
    plt.ylabel('Lift')
    plt.title('Lift Chart')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/lift_chart.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Generated all remaining plots (10-14) successfully!")

print("All visualization functions defined successfully!")
print("Ready to generate complete analysis.")