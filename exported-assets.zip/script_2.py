# Continue with metrics computation and visualization functions
def compute_metrics(probabilities, predictions, true_labels, confidence_scores, class_names):
    """
    Compute comprehensive evaluation metrics
    """
    n_classes = len(class_names)
    correct = (predictions == true_labels)
    
    metrics = {}
    
    # Basic accuracy
    accuracy = accuracy_score(true_labels, predictions)
    metrics['accuracy'] = accuracy
    
    # Negative Log-Likelihood
    try:
        nll = log_loss(true_labels, probabilities)
        metrics['nll'] = nll
    except:
        metrics['nll'] = np.nan
    
    # Brier Score (multiclass)
    try:
        # Convert to one-hot for Brier score
        y_true_onehot = np.eye(n_classes)[true_labels]
        brier = np.mean(np.sum((probabilities - y_true_onehot)**2, axis=1))
        metrics['brier'] = brier
    except:
        metrics['brier'] = np.nan
    
    # Expected Calibration Error (ECE)
    def compute_ece(confidences, accuracies, n_bins=15):
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        ece = 0
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            in_bin = (confidences > bin_lower) & (confidences <= bin_upper)
            prop_in_bin = in_bin.mean()
            
            if prop_in_bin > 0:
                accuracy_in_bin = accuracies[in_bin].mean()
                avg_confidence_in_bin = confidences[in_bin].mean()
                ece += np.abs(avg_confidence_in_bin - accuracy_in_bin) * prop_in_bin
        
        return ece
    
    ece_msp = compute_ece(confidence_scores['msp'], correct.astype(float))
    metrics['ece'] = ece_msp
    
    # Maximum Calibration Error (MCE)
    def compute_mce(confidences, accuracies, n_bins=15):
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        mce = 0
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            in_bin = (confidences > bin_lower) & (confidences <= bin_upper)
            prop_in_bin = in_bin.mean()
            
            if prop_in_bin > 0:
                accuracy_in_bin = accuracies[in_bin].mean()
                avg_confidence_in_bin = confidences[in_bin].mean()
                mce = max(mce, np.abs(avg_confidence_in_bin - accuracy_in_bin))
        
        return mce
    
    mce_msp = compute_mce(confidence_scores['msp'], correct.astype(float))
    metrics['mce'] = mce_msp
    
    # AUROC for confidence (binary: correct vs incorrect)
    try:
        auroc_conf = roc_auc_score(correct.astype(int), confidence_scores['msp'])
        metrics['auroc_confidence'] = auroc_conf
    except:
        metrics['auroc_confidence'] = np.nan
    
    # Sharpness (average confidence)
    sharpness = np.mean(confidence_scores['msp'])
    metrics['sharpness'] = sharpness
    
    # Per-class metrics
    per_class_metrics = {}
    for i, class_name in enumerate(class_names):
        class_mask = (true_labels == i)
        if np.sum(class_mask) > 0:
            class_acc = accuracy_score(true_labels[class_mask], predictions[class_mask])
            class_conf = np.mean(confidence_scores['msp'][class_mask])
            per_class_metrics[class_name] = {
                'accuracy': class_acc,
                'confidence': class_conf,
                'count': np.sum(class_mask)
            }
    
    metrics['per_class'] = per_class_metrics
    
    return metrics

def generate_visualizations(dataset, confidence_scores, calibration_results, metrics):
    """
    Generate all 14 required plots for the analysis
    """
    # Create figures directory
    os.makedirs('figures', exist_ok=True)
    
    probabilities = dataset['probabilities']
    predictions = dataset['predictions'] 
    true_labels = dataset['true_labels']
    class_names = dataset['class_names']
    correct = (predictions == true_labels)
    
    # 1. Overall Reliability Diagram
    plt.figure(figsize=(8, 6))
    fraction_of_positives, mean_predicted_value = calibration_curve(
        correct.astype(int), confidence_scores['msp'], n_bins=10
    )
    plt.plot(mean_predicted_value, fraction_of_positives, 's-', label='Model')
    plt.plot([0, 1], [0, 1], 'k--', label='Perfect Calibration')
    plt.xlabel('Mean Predicted Confidence')
    plt.ylabel('Fraction of Positives (Accuracy)')
    plt.title('Overall Reliability Diagram')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/reliability_overall.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 2. Per-Class Reliability Diagrams
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()
    
    for i, class_name in enumerate(class_names):
        ax = axes[i]
        class_mask = (true_labels == i)
        if np.sum(class_mask) > 5:  # Need sufficient samples
            class_correct = (predictions[class_mask] == true_labels[class_mask]).astype(int)
            class_conf = confidence_scores['msp'][class_mask]
            
            try:
                frac_pos, mean_pred = calibration_curve(class_correct, class_conf, n_bins=5)
                ax.plot(mean_pred, frac_pos, 's-', label=f'{class_name}')
                ax.plot([0, 1], [0, 1], 'k--', alpha=0.5)
            except:
                ax.text(0.5, 0.5, f'{class_name}\nInsufficient data', 
                       ha='center', va='center', transform=ax.transAxes)
        
        ax.set_xlabel('Mean Predicted Confidence')
        ax.set_ylabel('Fraction of Positives')
        ax.set_title(f'{class_name} Reliability')
        ax.grid(True, alpha=0.3)
    
    # Hide the extra subplot
    axes[-1].set_visible(False)
    plt.tight_layout()
    plt.savefig('figures/reliability_per_class.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 3. Adaptive Reliability Diagram (equal mass bins)
    plt.figure(figsize=(8, 6))
    
    # Sort by confidence and create equal-mass bins
    sorted_indices = np.argsort(confidence_scores['msp'])
    sorted_conf = confidence_scores['msp'][sorted_indices]
    sorted_correct = correct[sorted_indices].astype(int)
    
    n_bins = 10
    bin_size = len(sorted_conf) // n_bins
    
    bin_conf_means = []
    bin_acc_means = []
    
    for i in range(n_bins):
        start_idx = i * bin_size
        end_idx = (i + 1) * bin_size if i < n_bins - 1 else len(sorted_conf)
        
        bin_conf = sorted_conf[start_idx:end_idx]
        bin_correct = sorted_correct[start_idx:end_idx]
        
        bin_conf_means.append(np.mean(bin_conf))
        bin_acc_means.append(np.mean(bin_correct))
    
    plt.plot(bin_conf_means, bin_acc_means, 's-', label='Adaptive Bins')
    plt.plot([0, 1], [0, 1], 'k--', label='Perfect Calibration')
    plt.xlabel('Mean Predicted Confidence')
    plt.ylabel('Accuracy')
    plt.title('Adaptive Reliability Diagram (Equal Mass Bins)')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/reliability_adaptive.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 4. Confidence Agreement Boxplot
    plt.figure(figsize=(10, 6))
    
    conf_methods = ['MSP', 'Entropy', 'Margin']
    conf_values = [confidence_scores['msp'], confidence_scores['entropy'], confidence_scores['margin']]
    
    plt.boxplot(conf_values, labels=conf_methods)
    plt.ylabel('Confidence Score')
    plt.title('Distribution of Different Confidence Measures')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('figures/boxplot_agreement.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Generated first 4 plots successfully!")

# Test the visualization generation
print("Visualization functions defined successfully!")
print("Ready to generate all required plots.")